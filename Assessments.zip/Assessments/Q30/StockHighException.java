package Q30;

public class StockHighException extends Exception{
	public StockHighException(String s){
		super(s);
	}
}
