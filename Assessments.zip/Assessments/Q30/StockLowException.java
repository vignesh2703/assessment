package Q30;

public class StockLowException extends Exception{
	public StockLowException(String s) {
		super(s);
	}
}
